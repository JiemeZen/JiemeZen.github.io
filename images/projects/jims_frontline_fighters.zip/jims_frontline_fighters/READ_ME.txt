Thank you for trying my game!
-Jimmy

--------------------------------------------------------------------------------
'frontline_fighter.gba' is a game made for the GameBoy Advance machines, 
which were made in the early 21st century. However with the advanced computers,
you can emulate it using the attached 'VisualBoyAdvance.exe'.

Game Instructions:
1. Simply open 'VisualBoyAdvance.exe'
2. File > Open > 'frontline_fighter.gba'
3. Enjoy the game!

Game Controls:
Arrow Keys: Move up, down, left, right
X: Shoot - Requires Gun (Button 'B' of controller)

Game Objectives:
Collect the soap gun to kill all the virus to proceed to next level.
Some objects are pushable, however move carefully to ensure they do not block your path.

Cheats:
A: Previous Level (Button 'L' of controller)
S: Next Level (Button 'R' of controller)

--------------------------------------------------------------------------------
Website: jimmyzeng.tech
Email: hello@jimmyzeng.tech
LinkedIn: linkedin.com/in/j-zeng/